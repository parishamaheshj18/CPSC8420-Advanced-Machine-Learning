trainingID=[];
testID=[];
for i=1:400
    if mod(i,10)<9
        trainingID = [trainingID;i];
    else
        testID = [testID;i];
    end
end
X = [];
for j=1:size(trainingID,1)
    X = [X;M(j,:)];
end
mean_X = mean(X);
X = X-mean_X;
[U,S,V]=svd(X'*X);
%%
close all
projVectors=[];
for i=1:50
    projVectors=[projVectors,U(:,i)];
end
X_proj=X*projVectors;
testimg=M(testID(1),:);
test_proj=(testimg-mean_X)*projVectors;
com_dist = [ ];
for i = 1:size(X_proj,1)
    vec_dist = norm(test_proj - X_proj(i,:));
    com_dist = [com_dist vec_dist];
end
[match_min,match_index] = min(com_dist);
match_index
%%
close all;
figure
subplot(1,2,1)
imshow(reshape(M(9,:),112,92),[])
subplot(1,2,2)
imshow(reshape(M(10,:),112,92),[])
figure
subplot(2,2,1)
imshow(reshape(U(:,1),112,92),[])
subplot(2,2,2)
imshow(reshape(U(:,2),112,92),[])
subplot(2,2,3)
imshow(reshape(U(:,3),112,92),[])
subplot(2,2,4)
imshow(reshape(U(:,4),112,92),[])