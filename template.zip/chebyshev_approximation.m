%% Chebyshev approximation of sin(t) on N = 101 points 
%% using a 3rd order polynomial
%% Set default Matlab fontsizes etc to generate a plot 
set(0,'DefaultTextFontName','Times',...
      'DefaultTextFontSize',18,...
      'DefaultAxesFontName','Times',...
      'DefaultAxesFontSize',18,...
      'DefaultLineLineWidth',2,...
      'DefaultLineMarkerSize',7.75)
%% Setup and solve the optimization
N = 101;
tt = linspace(0,2*pi,N);
tt = tt(:); %Convert t to a column vector
T = [ones(N,1) tt tt.^2 tt.^3];
E=eye(5);
B=E(:,2:end)';
f=E(:,1);
One=ones(N,1);
A=[-T*B-One*f'; T*B-One*f'];
b=[-sin(tt); sin(tt)];

%% Solving by linprog()
x_star=linprog(f,A,b);
error=x_star(1)
a=x_star(2:5);

%% Generate plots
g = @(t) a(1) + a(2)*t + a(3)*t.^2 + a(4)*t.^3;
e=max(abs(sin(tt)-g(tt)));

plot(tt, sin(tt)-g(tt),'r-',tt,error*ones(N,1),'y-.',...
    tt,-error*ones(N,1),'y-.',tt,zeros(N,1),'g--');
L = legend('$f(t)-g(t)$','$\|f(t)-g(t)\|_{\infty}$',...
    '-$\|f(t)-g(t)\|_{\infty}$','h(t)=0');
set(L,'Interpreter','LaTex'); 
xlabel('$t$','Interpreter','LaTex');
ylabel('$f-g$','Interpreter','LaTex')
title('Chebyshev approximation to $\sin(t)$','Interpreter','LaTex');