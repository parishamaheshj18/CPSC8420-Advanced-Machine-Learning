clc
clear all
close all
rand('seed',2022)
load('Problem2_data.mat')
K = 10;                                            
KMI = 20;                                           
F = X;
CENTS = F( ceil(rand(K,1)*size(F,1)) ,:);             
DAL   = zeros(size(F,1),K+2);                         
obj = zeros(KMI,1);
for n = 1:KMI    
   for i = 1:size(F,1)
      for j = 1:K  
        DAL(i,j) = sum(abs(F(i,:) - CENTS(j,:)));      
      end
      [Distance, CN] = min(DAL(i,1:K));                
      DAL(i,K+1) = CN;                                
      DAL(i,K+2) = Distance;                          
   end
   obj(n) = sum(DAL(:,end));
   for i = 1:K
      A = (DAL(:,K+1) == i);                          
      CENTS(i,:) = median(F(A,:));      
      if sum(isnan(CENTS(:))) ~= 0                    
         NC = find(isnan(CENTS(:,1)) == 1); 
         for Ind = 1:size(NC,1)
            CENTS(NC(Ind),:) = F(randi(size(F,1)),:);
         end
      end
   end
end
figure;
plot(obj,'LineWidth', 1, 'MarkerSize', 1);
xlabel('Number of Iterations','FontSize',15);
ylabel('Objective','FontSize',15);
set(gca, 'FontSize',15);